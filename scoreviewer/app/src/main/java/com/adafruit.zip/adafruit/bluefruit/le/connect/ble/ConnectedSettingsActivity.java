package com.adafruit.bluefruit.le.connect.ble;

public class ConnectedSettingsActivity {
}
